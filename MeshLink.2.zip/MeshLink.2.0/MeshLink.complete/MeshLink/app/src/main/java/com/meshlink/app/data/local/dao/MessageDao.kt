package com.meshlink.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.meshlink.app.data.local.entity.MessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {

    /**
     * OnConflictStrategy.IGNORE on the messageId primary key means a message
     * that has already been stored can never be inserted a second time —
     * this IS the duplicate-prevention mechanism required by spec section 5
     * ("Use unique IDs to prevent duplicate messages") and section 6
     * ("Prevent duplicate forwarding using messageId"). Returns -1 when the
     * row already existed, which callers can use to detect a no-op insert.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(message: MessageEntity): Long

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun observeMessagesForConversation(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE messageId = :messageId")
    suspend fun getById(messageId: String): MessageEntity?

    @Query("SELECT EXISTS(SELECT 1 FROM messages WHERE messageId = :messageId)")
    suspend fun exists(messageId: String): Boolean

    @Query("UPDATE messages SET status = :status WHERE messageId = :messageId")
    suspend fun updateStatus(messageId: String, status: String)

    @Query("SELECT COUNT(*) FROM messages WHERE isOutgoing = 1 AND status = :status")
    fun observeCountByStatus(status: String): Flow<Int>

    /** Used when a peer just connected, to flush anything that queued up while offline. */
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId AND status = 'QUEUED' AND isOutgoing = 1")
    suspend fun getQueuedForConversation(conversationId: String): List<MessageEntity>

    /** Used by the periodic TTL sweep so a message can't stay QUEUED/circulating forever. */
    @Query("SELECT * FROM messages WHERE status = 'QUEUED' AND isOutgoing = 1")
    suspend fun getAllQueuedOutgoing(): List<MessageEntity>
}
