package com.meshlink.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.meshlink.app.data.DemoData
import com.meshlink.app.data.MeshStatus
import com.meshlink.app.data.PeerConnectionState
import com.meshlink.app.data.PeerDeviceUi
import com.meshlink.app.mesh.MeshPermissions
import com.meshlink.app.viewmodel.NearbyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NearbyScreen(viewModel: NearbyViewModel) {
    val context = LocalContext.current
    val meshStatus by viewModel.meshStatus.collectAsState()
    val realPeers by viewModel.peers.collectAsState()
    var permissionDenied by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            permissionDenied = false
            viewModel.startScan()
        } else {
            // Real denial handling: never proceed as if permissions were
            // granted, and never crash — just surface it.
            permissionDenied = true
        }
    }

    val isScanningOrConnected = meshStatus == MeshStatus.SCANNING || meshStatus == MeshStatus.CONNECTED

    Scaffold(
        topBar = { TopAppBar(title = { Text("Nearby") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Button(
                onClick = {
                    if (isScanningOrConnected) {
                        viewModel.stopScan()
                    } else if (MeshPermissions.hasAll(context)) {
                        permissionDenied = false
                        viewModel.startScan()
                    } else {
                        permissionLauncher.launch(MeshPermissions.required())
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isScanningOrConnected) "Stop Scan" else "SCAN")
            }

            Spacer(Modifier.height(12.dp))

            if (permissionDenied) {
                PermissionDeniedCard(onRetry = { permissionLauncher.launch(MeshPermissions.required()) })
                Spacer(Modifier.height(16.dp))
            }

            if (meshStatus == MeshStatus.SCANNING) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text(
                    "Discovering and advertising to nearby MeshLink devices over Bluetooth/Wi-Fi \u2014 " +
                        "no internet involved.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Spacer(Modifier.height(16.dp))
            }

            Text("Real Devices", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            if (realPeers.isEmpty()) {
                EmptyState(
                    if (isScanningOrConnected)
                        "Scanning\u2026 no MeshLink peers found yet. Make sure the other phone " +
                            "also has MeshLink open with Nearby scanning turned on and is within " +
                            "Bluetooth/Wi-Fi range."
                    else
                        "Tap SCAN to discover real nearby MeshLink devices over Bluetooth/Wi-Fi."
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(realPeers, key = { it.id }) { peer ->
                        RealPeerRow(
                            peer = peer,
                            onConnect = { viewModel.connect(peer.id) },
                            onDisconnect = { viewModel.disconnect(peer.id) }
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Demo Peers", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.width(8.dp))
                StatusChip("DEMO DATA", MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(8.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(DemoData.demoPeers, key = { it.id }) { peer ->
                    PeerRow(peer)
                }
            }
        }
    }
}

@Composable
private fun PermissionDeniedCard(onRetry: () -> Unit) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("Permission needed", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            MeshPermissions.required().forEach { permission ->
                Text(
                    "\u2022 " + MeshPermissions.rationale(permission),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "MeshLink can't discover or connect to nearby devices without these. " +
                    "Nothing else in the app is affected - Home, Chat, and Settings still work.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onRetry) { Text("Grant permissions") }
        }
    }
}

@Composable
private fun RealPeerRow(peer: PeerDeviceUi, onConnect: () -> Unit, onDisconnect: () -> Unit) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(peer.displayName, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                StatusChip(labelForPeerState(peer.state), colorForPeerState(peer.state))
            }

            when (peer.state) {
                PeerConnectionState.AVAILABLE -> TextButton(onClick = onConnect) { Text("CONNECT") }
                PeerConnectionState.CONNECTED -> TextButton(onClick = onDisconnect) { Text("DISCONNECT") }
                PeerConnectionState.CONNECTING -> CircularProgressIndicator(modifier = Modifier.size(20.dp))
                PeerConnectionState.DISCONNECTED -> TextButton(onClick = onConnect) { Text("RECONNECT") }
            }
        }
    }
}

@Composable
private fun PeerRow(peer: PeerDeviceUi) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(peer.displayName, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.width(6.dp))
                    StatusChip("DEMO", MaterialTheme.colorScheme.error)
                }
                Spacer(Modifier.height(4.dp))
                StatusChip(labelForPeerState(peer.state), colorForPeerState(peer.state))
            }

            when (peer.state) {
                PeerConnectionState.AVAILABLE -> TextButton(onClick = { }) { Text("CONNECT") }
                PeerConnectionState.CONNECTED -> TextButton(onClick = { }) { Text("DISCONNECT") }
                PeerConnectionState.CONNECTING -> CircularProgressIndicator(modifier = Modifier.size(20.dp))
                PeerConnectionState.DISCONNECTED -> TextButton(onClick = { }) { Text("RETRY") }
            }
        }
    }
}
