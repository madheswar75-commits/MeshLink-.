package com.meshlink.app.mesh

import android.content.Context
import android.util.Log
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.concurrent.ConcurrentHashMap

/**
 * The real communication layer. Wraps Google Play services' Nearby
 * Connections API, which is what "Bluetooth/Wi-Fi Nearby APIs" in the spec
 * points at: under P2P_CLUSTER strategy it uses BLE for discovery/advertising
 * and Bluetooth/Wi-Fi for the actual data transfer, entirely on-device —
 * no internet round trip, no server relaying payloads, no Firebase/
 * WhatsApp/Telegram involved anywhere in this class.
 *
 * KNOWN SIMPLIFICATION (documented, not hidden): incoming connection
 * requests are auto-accepted. There is no pairing-confirmation UI yet and
 * no cryptographic identity check — any nearby device advertising the
 * MeshLink service ID will be accepted. This is acceptable for Phase 3
 * (getting real bytes moving between two phones) and is explicitly what
 * Phase 7 (Security) exists to fix: device identity + authenticated
 * pairing before messages are trusted.
 *
 * Nearby Connections requires Google Play services on the device. It will
 * not function on a bare AOSP emulator image without Play services, or on
 * a device with Play services disabled — this is a real platform
 * constraint, not a bug in this code.
 */
class MeshTransportManager(private val appContext: Context) {

    private val connectionsClient: ConnectionsClient by lazy { Nearby.getConnectionsClient(appContext) }
    private val strategy = Strategy.P2P_CLUSTER

    @Volatile private var localUserId: String? = null
    @Volatile private var localDisplayName: String = "MeshLink User"

    @Volatile var isDiscovering: Boolean = false
        private set
    @Volatile var isAdvertising: Boolean = false
        private set

    // Nearby's endpointId is ephemeral (new every discovery session). We map
    // it to our own stable `peerId` (a UUID persisted in Room across app
    // restarts), which is encoded into the advertised endpoint name as
    // "<peerId>|<displayName>". Everything outside this class only ever
    // sees the stable peerId.
    private val endpointToPeer = ConcurrentHashMap<String, String>()
    private val peerToEndpoint = ConcurrentHashMap<String, String>()

    // Nearby's Payload.id (a Long, assigned when we build the Payload) is
    // how PayloadTransferUpdate reports success/failure — it has no idea
    // about our messageId, so we track that mapping ourselves.
    private val payloadToMessage = ConcurrentHashMap<Long, String>()

    private val _events = MutableSharedFlow<MeshTransportEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<MeshTransportEvent> = _events.asSharedFlow()

    fun setLocalIdentity(userId: String, displayName: String) {
        localUserId = userId
        localDisplayName = displayName.take(24).ifBlank { "MeshLink User" }
    }

    fun startDiscovery() {
        val options = DiscoveryOptions.Builder().setStrategy(strategy).build()
        connectionsClient.startDiscovery(SERVICE_ID, endpointDiscoveryCallback, options)
            .addOnSuccessListener {
                isDiscovering = true
                Log.i(TAG, "Discovery started")
            }
            .addOnFailureListener {
                isDiscovering = false
                Log.e(TAG, "Discovery failed to start", it)
                emit(MeshTransportEvent.TransportError("Could not start discovery: ${it.message}"))
            }
    }

    fun stopDiscovery() {
        connectionsClient.stopDiscovery()
        isDiscovering = false
        Log.i(TAG, "Discovery stopped")
    }

    fun startAdvertising() {
        val uid = localUserId
        if (uid == null) {
            Log.e(TAG, "startAdvertising called before setLocalIdentity")
            emit(MeshTransportEvent.TransportError("Local identity not set yet"))
            return
        }
        val endpointName = "$uid|$localDisplayName"
        val options = AdvertisingOptions.Builder().setStrategy(strategy).build()
        connectionsClient.startAdvertising(endpointName, SERVICE_ID, connectionLifecycleCallback, options)
            .addOnSuccessListener {
                isAdvertising = true
                Log.i(TAG, "Advertising started as $endpointName")
            }
            .addOnFailureListener {
                isAdvertising = false
                Log.e(TAG, "Advertising failed to start", it)
                emit(MeshTransportEvent.TransportError("Could not start advertising: ${it.message}"))
            }
    }

    fun stopAdvertising() {
        connectionsClient.stopAdvertising()
        isAdvertising = false
        Log.i(TAG, "Advertising stopped")
    }

    fun connect(peerId: String) {
        val endpointId = peerToEndpoint[peerId]
        val uid = localUserId
        if (endpointId == null) {
            Log.w(TAG, "connect($peerId): peer not currently discoverable")
            emit(MeshTransportEvent.ConnectionFailed(peerId, "Peer is no longer nearby"))
            return
        }
        if (uid == null) {
            emit(MeshTransportEvent.ConnectionFailed(peerId, "Local identity not set yet"))
            return
        }
        connectionsClient.requestConnection("$uid|$localDisplayName", endpointId, connectionLifecycleCallback)
            .addOnFailureListener {
                Log.e(TAG, "requestConnection to $peerId failed", it)
                emit(MeshTransportEvent.ConnectionFailed(peerId, it.message))
            }
    }

    fun disconnect(peerId: String) {
        val endpointId = peerToEndpoint[peerId] ?: return
        connectionsClient.disconnectFromEndpoint(endpointId)
        peerToEndpoint.remove(peerId)
        endpointToPeer.remove(endpointId)
        emit(MeshTransportEvent.Disconnected(peerId))
    }

    fun disconnectAll() {
        connectionsClient.stopAllEndpoints()
        peerToEndpoint.clear()
        endpointToPeer.clear()
    }

    /**
     * Sends one envelope to one connected peer. Returns false immediately
     * (no exception, no crash) if that peer has no live endpoint right
     * now — callers rely on this to safely leave a message QUEUED instead
     * of pretending it was sent.
     */
    fun send(peerId: String, envelope: MeshEnvelope): Boolean {
        val endpointId = peerToEndpoint[peerId] ?: return false
        return try {
            val bytes = envelope.toJson().toByteArray(Charsets.UTF_8)
            val payload = Payload.fromBytes(bytes)
            if (envelope.type == "message") {
                payloadToMessage[payload.id] = envelope.messageId
            }
            connectionsClient.sendPayload(endpointId, payload)
                .addOnFailureListener {
                    Log.e(TAG, "sendPayload to $peerId failed", it)
                    if (envelope.type == "message") emit(MeshTransportEvent.MessageSendFailed(envelope.messageId))
                }
            true
        } catch (e: Exception) {
            Log.e(TAG, "send() threw for $peerId", e)
            if (envelope.type == "message") emit(MeshTransportEvent.MessageSendFailed(envelope.messageId))
            false
        }
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            if (info.serviceId != SERVICE_ID) return
            val parsed = parseEndpointName(info.endpointName) ?: return
            val (peerId, name) = parsed
            endpointToPeer[endpointId] = peerId
            peerToEndpoint[peerId] = endpointId
            Log.i(TAG, "Endpoint found: $name ($peerId)")
            emit(MeshTransportEvent.PeerFound(peerId, name))
        }

        override fun onEndpointLost(endpointId: String) {
            val peerId = endpointToPeer.remove(endpointId) ?: return
            peerToEndpoint.remove(peerId)
            Log.i(TAG, "Endpoint lost: $peerId")
            emit(MeshTransportEvent.PeerLost(peerId))
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            val parsed = parseEndpointName(info.endpointName) ?: return
            val (peerId, _) = parsed
            endpointToPeer[endpointId] = peerId
            peerToEndpoint[peerId] = endpointId
            Log.i(TAG, "Connection initiated with $peerId")
            emit(MeshTransportEvent.Connecting(peerId))
            // Auto-accept — see class kdoc "KNOWN SIMPLIFICATION".
            connectionsClient.acceptConnection(endpointId, payloadCallback)
                .addOnFailureListener { Log.e(TAG, "acceptConnection failed for $peerId", it) }
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            val peerId = endpointToPeer[endpointId] ?: return
            if (result.status.isSuccess) {
                Log.i(TAG, "Connected to $peerId")
                emit(MeshTransportEvent.Connected(peerId))
            } else {
                Log.w(TAG, "Connection to $peerId failed: ${result.status.statusMessage}")
                emit(MeshTransportEvent.ConnectionFailed(peerId, result.status.statusMessage))
            }
        }

        override fun onDisconnected(endpointId: String) {
            val peerId = endpointToPeer.remove(endpointId) ?: return
            peerToEndpoint.remove(peerId)
            Log.i(TAG, "Disconnected from $peerId")
            emit(MeshTransportEvent.Disconnected(peerId))
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = payload.asBytes() ?: return
            val peerId = endpointToPeer[endpointId] ?: return
            val envelope = MeshEnvelope.fromJson(String(bytes, Charsets.UTF_8))
            if (envelope == null) {
                Log.w(TAG, "Received malformed payload from $peerId, dropping")
                return
            }
            emit(MeshTransportEvent.MessageReceived(peerId, envelope))
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            val messageId = payloadToMessage[update.payloadId] ?: return
            when (update.status) {
                PayloadTransferUpdate.Status.SUCCESS -> {
                    payloadToMessage.remove(update.payloadId)
                    emit(MeshTransportEvent.MessageSendSucceeded(messageId))
                }
                PayloadTransferUpdate.Status.FAILURE -> {
                    payloadToMessage.remove(update.payloadId)
                    Log.w(TAG, "Payload transfer FAILED for message $messageId")
                    emit(MeshTransportEvent.MessageSendFailed(messageId))
                }
                PayloadTransferUpdate.Status.CANCELED -> {
                    payloadToMessage.remove(update.payloadId)
                    Log.w(TAG, "Payload transfer CANCELED for message $messageId")
                    emit(MeshTransportEvent.MessageSendFailed(messageId))
                }
                else -> Unit // IN_PROGRESS — nothing to report yet
            }
        }
    }

    private fun parseEndpointName(raw: String): Pair<String, String>? {
        val idx = raw.indexOf('|')
        if (idx <= 0) return null
        return raw.substring(0, idx) to raw.substring(idx + 1)
    }

    private fun emit(event: MeshTransportEvent) {
        if (!_events.tryEmit(event)) {
            Log.w(TAG, "Event buffer full, dropped: $event")
        }
    }

    companion object {
        private const val TAG = "MeshTransportManager"
        private const val SERVICE_ID = "com.meshlink.app.SERVICE_ID"
    }
}
