package com.meshlink.app.util

import java.util.UUID

/**
 * Central place for generating the unique IDs the spec requires
 * (messageId, conversationId, peerId, emergencyId, userId). All are UUIDv4
 * strings — good enough to guarantee practical uniqueness across devices
 * without any coordination, which matters since there is no server to
 * hand out IDs in an offline mesh.
 */
object Ids {
    fun newId(): String = UUID.randomUUID().toString()
}
