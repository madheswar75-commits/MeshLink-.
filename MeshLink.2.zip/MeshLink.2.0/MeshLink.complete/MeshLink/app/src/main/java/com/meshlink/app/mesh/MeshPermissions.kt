package com.meshlink.app.mesh

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * The exact runtime permissions MeshLink needs to discover/connect to
 * nearby peers, and why — per spec section 8: request only what's needed
 * for the chosen technology (Nearby Connections, which uses BLE + classic
 * Bluetooth + Wi-Fi under the hood), and explain each one.
 *
 * No INTERNET permission is requested anywhere in this app — it is not
 * needed for local device-to-device discovery/connection/transfer, and
 * requesting it would contradict the offline-first requirement.
 */
object MeshPermissions {

    /** The exact set to request, chosen by API level. */
    fun required(): Array<String> = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.NEARBY_WIFI_DEVICES
        )
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        else -> arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    }

    fun hasAll(context: Context): Boolean = required().all { permission ->
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    /** Shown in-app so the person knows exactly why each permission is asked for. */
    fun rationale(permission: String): String = when (permission) {
        Manifest.permission.BLUETOOTH_SCAN ->
            "Bluetooth scan — to discover nearby MeshLink devices."
        Manifest.permission.BLUETOOTH_ADVERTISE ->
            "Bluetooth advertise — so nearby MeshLink devices can discover this phone."
        Manifest.permission.BLUETOOTH_CONNECT ->
            "Bluetooth connect — to open a direct link with a nearby MeshLink device."
        Manifest.permission.NEARBY_WIFI_DEVICES ->
            "Nearby Wi-Fi devices — for local Wi-Fi-based discovery/transfer (no router or internet involved)."
        Manifest.permission.ACCESS_FINE_LOCATION ->
            "Location — required by Android on this OS version for Bluetooth/Wi-Fi peer discovery to " +
                "function at all. MeshLink does not read GPS location or track where you are."
        else -> "Required for offline device-to-device communication."
    }
}
