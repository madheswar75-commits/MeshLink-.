package com.meshlink.app

import android.app.Application

/**
 * Application entry point.
 *
 * Phase 1: no-op besides Application boilerplate.
 * Phase 2+: this is where the Room database instance, the MeshRepository,
 * and (Phase 3+) the MeshTransportManager (Bluetooth/Wi-Fi layer) will be
 * constructed as singletons and handed to ViewModels via a simple manual
 * DI provider (see data/ServiceLocator.kt, added in Phase 2).
 */
class MeshLinkApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
