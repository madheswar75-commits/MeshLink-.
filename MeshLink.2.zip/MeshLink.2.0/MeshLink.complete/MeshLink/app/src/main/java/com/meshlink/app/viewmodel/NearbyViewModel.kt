package com.meshlink.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.meshlink.app.data.MeshStatus
import com.meshlink.app.data.PeerDeviceUi
import com.meshlink.app.data.repository.MeshRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class NearbyViewModel(private val repository: MeshRepository) : ViewModel() {

    val peers: StateFlow<List<PeerDeviceUi>> = repository.observeDiscoveredPeers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Repository's own StateFlow already reflects real, live transport
    // state — re-scoped here only so it follows this screen's lifecycle.
    val meshStatus: StateFlow<MeshStatus> = repository.observeMeshStatus()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MeshStatus.OFFLINE)

    /** Caller (the screen) must confirm runtime permissions are granted before calling this. */
    fun startScan() = repository.startDiscovery()

    fun stopScan() = repository.stopDiscovery()

    fun connect(peerId: String) = repository.connectToPeer(peerId)

    fun disconnect(peerId: String) = repository.disconnectFromPeer(peerId)

    class Factory(private val repository: MeshRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = NearbyViewModel(repository) as T
    }
}
