package com.meshlink.app.navigation

import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.meshlink.app.data.ServiceLocator
import com.meshlink.app.ui.screens.ChatScreen
import com.meshlink.app.ui.screens.EmergencyScreen
import com.meshlink.app.ui.screens.HomeScreen
import com.meshlink.app.ui.screens.MeshScreen
import com.meshlink.app.ui.screens.NearbyScreen
import com.meshlink.app.ui.screens.SettingsScreen
import com.meshlink.app.viewmodel.ChatViewModel
import com.meshlink.app.viewmodel.EmergencyViewModel
import com.meshlink.app.viewmodel.HomeViewModel
import com.meshlink.app.viewmodel.NearbyViewModel

@Composable
fun MeshLinkNavGraph() {
    val navController = rememberNavController()
    // Single Room-backed repository instance for the whole app (Phase 2).
    // Phase 3+ will add a MeshTransportManager alongside it, provided the
    // same way, without changing how screens obtain their ViewModels.
    val context = LocalContext.current
    val repository = remember(context) { ServiceLocator.provideRepository(context.applicationContext) }

    Scaffold(
        bottomBar = { MeshLinkBottomBar(navController) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = BottomDestination.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(BottomDestination.Home.route) {
                val homeViewModel: HomeViewModel = viewModel(factory = HomeViewModel.Factory(repository))
                HomeScreen(
                    viewModel = homeViewModel,
                    onOpenConversation = { id -> navController.navigate(DetailRoutes.chat(id)) }
                )
            }
            composable(BottomDestination.Nearby.route) {
                val nearbyViewModel: NearbyViewModel = viewModel(factory = NearbyViewModel.Factory(repository))
                NearbyScreen(viewModel = nearbyViewModel)
            }
            composable(BottomDestination.Mesh.route) {
                val meshPeersViewModel: NearbyViewModel = viewModel(factory = NearbyViewModel.Factory(repository))
                MeshScreen(viewModel = meshPeersViewModel)
            }
            composable(BottomDestination.Emergency.route) {
                val emergencyViewModel: EmergencyViewModel = viewModel(factory = EmergencyViewModel.Factory(repository))
                EmergencyScreen(viewModel = emergencyViewModel)
            }
            composable(BottomDestination.Settings.route) { SettingsScreen() }

            composable(
                route = DetailRoutes.CHAT,
                arguments = listOf(navArgument(DetailRoutes.CHAT_ARG_CONVERSATION_ID) { type = NavType.StringType })
            ) { backStackEntry ->
                val conversationId = backStackEntry.arguments?.getString(DetailRoutes.CHAT_ARG_CONVERSATION_ID).orEmpty()
                val chatViewModel: ChatViewModel = viewModel(
                    key = conversationId,
                    factory = ChatViewModel.Factory(repository, conversationId)
                )
                ChatScreen(viewModel = chatViewModel, onBack = { navController.popBackStack() })
            }
        }
    }
}

@Composable
private fun MeshLinkBottomBar(navController: androidx.navigation.NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination

    NavigationBar {
        BottomDestination.items.forEach { destination ->
            val selected = currentRoute?.hierarchy?.any { it.route == destination.route } == true
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(destination.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = {
                    androidx.compose.material3.Icon(
                        imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                        contentDescription = destination.label
                    )
                },
                label = { Text(destination.label) }
            )
        }
    }
}
