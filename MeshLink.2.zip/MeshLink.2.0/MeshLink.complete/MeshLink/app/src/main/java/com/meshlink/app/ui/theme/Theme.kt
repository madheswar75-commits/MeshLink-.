package com.meshlink.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColors = darkColorScheme(
    primary = MeshBlue80,
    onPrimary = MeshBlue20,
    secondary = MeshGreenSignal,
    tertiary = MeshRedEmergency,
    background = NeutralGray10,
    surface = NeutralGray20,
    onBackground = NeutralGray90,
    onSurface = NeutralGray90
)

private val LightColors = lightColorScheme(
    primary = MeshBlue40,
    onPrimary = NeutralGray99,
    secondary = MeshGreenSignal,
    tertiary = MeshRedEmergency,
    background = NeutralGray99,
    surface = NeutralGray99,
    onBackground = NeutralGray10,
    onSurface = NeutralGray10
)

/**
 * @param dynamicColor Uses Android 12+ Material You wallpaper-based colors when available.
 *                      Set false if you want the fixed MeshLink brand palette everywhere.
 */
@Composable
fun MeshLinkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = MeshLinkTypography,
        content = content
    )
}
