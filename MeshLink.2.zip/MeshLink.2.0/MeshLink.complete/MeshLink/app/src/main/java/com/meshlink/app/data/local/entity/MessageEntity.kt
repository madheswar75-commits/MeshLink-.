package com.meshlink.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A single message, outgoing or incoming.
 *
 * `messageId` is a UUID generated at creation time and is the PRIMARY KEY.
 * Every insert in [com.meshlink.app.data.local.dao.MessageDao] uses
 * OnConflictStrategy.IGNORE keyed on this column, which is the mechanism
 * spec section 5/6 calls for: "Use unique IDs to prevent duplicate
 * messages" and "Prevent duplicate forwarding using messageId". In Phase 2
 * this only matters for local inserts; from Phase 5 (multi-hop relay) the
 * exact same mechanism stops a relayed message from being re-forwarded or
 * re-displayed when it loops back through another path.
 *
 * `status` and `priority` are stored as the plain `.name` of
 * [com.meshlink.app.data.MessageStatus] / [com.meshlink.app.data.MessagePriority]
 * rather than via a Room TypeConverter, to keep the schema simple and
 * human-readable when inspected directly.
 */
@Entity(
    tableName = "messages",
    indices = [Index("conversationId")]
)
data class MessageEntity(
    @PrimaryKey val messageId: String,
    val conversationId: String,
    val senderId: String,
    val receiverId: String,
    val content: String,
    val timestamp: Long,
    val status: String,      // MessageStatus.name — QUEUED | SENT | RELAYED | DELIVERED | FAILED
    val priority: String,    // MessagePriority.name — NORMAL | IMPORTANT | EMERGENCY
    val hopCount: Int = 0,
    val expiryTime: Long,
    val isOutgoing: Boolean
)
