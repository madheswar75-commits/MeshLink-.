package com.meshlink.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.meshlink.app.data.local.entity.EmergencyMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface EmergencyMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: EmergencyMessageEntity)

    @Query("SELECT * FROM emergency_messages ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<EmergencyMessageEntity>>

    @Query("UPDATE emergency_messages SET status = :status WHERE emergencyId = :emergencyId")
    suspend fun updateStatus(emergencyId: String, status: String)
}
