package com.meshlink.app.data

/**
 * These are the shared status/type enums the whole app is built around.
 * In Phase 1 they back hardcoded/preview UI state only.
 * From Phase 2 onward, these exact enums become Room-persisted columns
 * on the Message / PeerDevice entities described in the project spec —
 * defining them once, here, means the UI layer never has to change when
 * the persistence layer is wired in.
 */

/** Lifecycle of an outgoing/incoming message. */
enum class MessageStatus {
    QUEUED,     // Written to Room, not yet handed to the transport layer
    SENT,       // Handed off to a directly connected peer
    RELAYED,    // Forwarded by an intermediate peer on behalf of someone else
    DELIVERED,  // Acknowledged received by the final destination
    FAILED      // No route found / expired before delivery
}

enum class MessagePriority { NORMAL, IMPORTANT, EMERGENCY }

/** Real connection lifecycle for a nearby peer — never skips a state. */
enum class PeerConnectionState {
    AVAILABLE,    // Discovered, not connected
    CONNECTING,   // Handshake in progress
    CONNECTED,    // Live, usable link
    DISCONNECTED  // Was connected, link lost
}

/** Aggregate mesh status shown on Home/Mesh screens. */
enum class MeshStatus { OFFLINE, SCANNING, CONNECTED }

data class PeerDeviceUi(
    val id: String,
    val displayName: String,
    val state: PeerConnectionState,
    val hopsAway: Int = 1,
    val isDemo: Boolean = false
)

data class MessageUi(
    val id: String,
    val text: String,
    val timestamp: String,
    val status: MessageStatus,
    val isOutgoing: Boolean,
    val priority: MessagePriority = MessagePriority.NORMAL,
    val hopCount: Int = 0
)

data class ConversationUi(
    val id: String,
    val peerName: String,
    val lastMessage: String,
    val lastTimestamp: String,
    val unreadCount: Int = 0
)
