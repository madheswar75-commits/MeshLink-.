package com.meshlink.app.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.ui.graphics.vector.ImageVector

/** Every top-level screen reachable from the bottom navigation bar. */
sealed class BottomDestination(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Home : BottomDestination("home", "Home", Icons.Filled.Home, Icons.Outlined.Home)
    data object Nearby : BottomDestination("nearby", "Nearby", Icons.Filled.Wifi, Icons.Outlined.Wifi)
    data object Mesh : BottomDestination("mesh", "Mesh", Icons.Filled.Hub, Icons.Outlined.Hub)
    data object Emergency : BottomDestination("emergency", "Emergency", Icons.Filled.Warning, Icons.Outlined.Warning)
    data object Settings : BottomDestination("settings", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)

    companion object {
        val items = listOf(Home, Nearby, Mesh, Emergency, Settings)
    }
}

/** Routes not shown in the bottom bar, pushed on top of it (e.g. an open conversation). */
object DetailRoutes {
    const val CHAT = "chat/{conversationId}"
    fun chat(conversationId: String) = "chat/$conversationId"
    const val CHAT_ARG_CONVERSATION_ID = "conversationId"
}
