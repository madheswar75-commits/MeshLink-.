package com.meshlink.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Record of an emergency alert the user triggered from the Emergency screen.
 *
 * `messageId` links back to the underlying [MessageEntity] (priority =
 * EMERGENCY), so the full send/relay/delivery history is tracked exactly
 * like a normal message — this table just keeps a dedicated, easy-to-query
 * log of "everything sent as an emergency," independent of which
 * conversation (if any) it's attached to.
 */
@Entity(tableName = "emergency_messages")
data class EmergencyMessageEntity(
    @PrimaryKey val emergencyId: String,
    val messageId: String,
    val content: String,
    val createdAt: Long,
    val status: String, // MessageStatus.name
    val hopCount: Int = 0
)
