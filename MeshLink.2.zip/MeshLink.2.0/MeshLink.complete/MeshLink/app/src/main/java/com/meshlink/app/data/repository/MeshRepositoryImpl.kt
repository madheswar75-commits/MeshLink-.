package com.meshlink.app.data.repository

import android.content.Context
import android.util.Log
import com.meshlink.app.data.MeshStatus
import com.meshlink.app.data.MessagePriority
import com.meshlink.app.data.MessageStatus
import com.meshlink.app.data.PeerConnectionState
import com.meshlink.app.data.PeerDeviceUi
import com.meshlink.app.data.local.MeshLinkDatabase
import com.meshlink.app.data.local.entity.ConversationEntity
import com.meshlink.app.data.local.entity.EmergencyMessageEntity
import com.meshlink.app.data.local.entity.MessageEntity
import com.meshlink.app.data.local.entity.PeerDeviceEntity
import com.meshlink.app.data.local.entity.UserEntity
import com.meshlink.app.data.toUi
import com.meshlink.app.mesh.MeshEnvelope
import com.meshlink.app.mesh.MeshTransportEvent
import com.meshlink.app.mesh.MeshTransportManager
import com.meshlink.app.util.Ids
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private const val TAG = "MeshRepository"
private const val NORMAL_TTL_MS = 24L * 60 * 60 * 1000   // 24h — a queued chat message stops being retried/shown as pending after this
private const val EMERGENCY_TTL_MS = 6L * 60 * 60 * 1000 // 6h — emergency alerts expire sooner so stale alerts don't linger/circulate
private const val EMERGENCY_BROADCAST_CONVERSATION_ID = "emergency-broadcast"
private const val EMERGENCY_RECEIVER_ID = "broadcast"
private const val MAX_RELAY_HOPS = 5                      // "do not allow messages to circulate indefinitely"
private const val EXPIRY_SWEEP_INTERVAL_MS = 60_000L

class MeshRepositoryImpl(
    private val context: Context,
    private val db: MeshLinkDatabase
) : MeshRepository {

    private val userDao = db.userDao()
    private val messageDao = db.messageDao()
    private val conversationDao = db.conversationDao()
    private val peerDeviceDao = db.peerDeviceDao()
    private val emergencyDao = db.emergencyMessageDao()

    private val transportManager = MeshTransportManager(context)

    // Lives for the app's lifetime (repository is a ServiceLocator singleton).
    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _meshStatus = MutableStateFlow(MeshStatus.OFFLINE)

    init {
        repositoryScope.launch {
            transportManager.events.collect { event ->
                try {
                    handleTransportEvent(event)
                } catch (e: Exception) {
                    // A single bad event must never silently kill the whole
                    // collector — log it and keep processing future events.
                    Log.e(TAG, "Error handling transport event $event", e)
                }
            }
        }
        repositoryScope.launch {
            while (true) {
                delay(EXPIRY_SWEEP_INTERVAL_MS)
                sweepExpiredMessages()
            }
        }
    }

    // -------- User --------

    override fun observeCurrentUser(): Flow<UserEntity?> = userDao.observeCurrentUser()

    override suspend fun ensureLocalUser(defaultDisplayName: String, defaultDeviceName: String): UserEntity {
        userDao.getCurrentUserOnce()?.let { return it }
        val user = UserEntity(
            userId = Ids.newId(),
            displayName = defaultDisplayName,
            deviceName = defaultDeviceName,
            createdAt = System.currentTimeMillis()
        )
        userDao.upsert(user)
        return user
    }

    private suspend fun currentUserId(): String =
        userDao.getCurrentUserOnce()?.userId ?: ensureLocalUser("You", "This Device").userId

    // -------- Conversations --------

    override fun observeConversations(): Flow<List<ConversationEntity>> = conversationDao.observeAll()

    override suspend fun createManualConversation(peerDisplayName: String): ConversationEntity {
        val peerId = Ids.newId()
        peerDeviceDao.upsert(
            PeerDeviceEntity(
                peerId = peerId,
                displayName = peerDisplayName,
                connectionState = PeerConnectionState.DISCONNECTED.name,
                source = "MANUAL",
                lastSeenTimestamp = System.currentTimeMillis()
            )
        )
        return getOrCreateConversationForPeer(peerId, peerDisplayName)
    }

    private suspend fun getOrCreateConversationForPeer(peerId: String, peerDisplayName: String): ConversationEntity {
        conversationDao.getByPeerId(peerId)?.let { return it }
        val conversation = ConversationEntity(
            conversationId = Ids.newId(),
            peerId = peerId,
            peerDisplayName = peerDisplayName,
            lastMessagePreview = "",
            lastMessageTimestamp = 0L,
            unreadCount = 0
        )
        conversationDao.upsert(conversation)
        return conversation
    }

    // -------- Messages --------

    override fun observeMessages(conversationId: String): Flow<List<MessageEntity>> =
        messageDao.observeMessagesForConversation(conversationId)

    override suspend fun sendMessage(
        conversationId: String,
        content: String,
        priority: MessagePriority
    ): MessageEntity {
        val senderId = currentUserId()
        val conversation = conversationDao.getById(conversationId)
        val now = System.currentTimeMillis()

        val message = MessageEntity(
            messageId = Ids.newId(),
            conversationId = conversationId,
            senderId = senderId,
            receiverId = conversation?.peerId ?: "unknown",
            content = content,
            timestamp = now,
            // Offline-first: always QUEUED first, in Room, before any
            // transport attempt. Real transitions to SENT/DELIVERED/FAILED
            // only ever happen from handleTransportEvent(), driven by real
            // Nearby Connections callbacks below — never faked here.
            status = MessageStatus.QUEUED.name,
            priority = priority.name,
            hopCount = 0,
            expiryTime = now + NORMAL_TTL_MS,
            isOutgoing = true
        )
        messageDao.insert(message)
        conversationDao.updateLastMessage(conversationId, content, now)

        conversation?.peerId?.let { peerId ->
            val envelope = message.toOutgoingEnvelope()
            // send() returns false immediately (no exception) if the peer
            // isn't connected right now — the message correctly just stays
            // QUEUED, to be retried automatically once that peer connects.
            transportManager.send(peerId, envelope)
        }
        return message
    }

    override fun observePendingMessageCount(): Flow<Int> =
        messageDao.observeCountByStatus(MessageStatus.QUEUED.name)

    override fun observeConnectedPeerCount(): Flow<Int> = peerDeviceDao.observeConnectedCount()

    // -------- Emergency --------

    override fun observeEmergencyHistory(): Flow<List<EmergencyMessageEntity>> = emergencyDao.observeAll()

    override suspend fun sendEmergencyMessage(content: String): EmergencyMessageEntity {
        val senderId = currentUserId()
        val now = System.currentTimeMillis()

        val message = MessageEntity(
            messageId = Ids.newId(),
            conversationId = EMERGENCY_BROADCAST_CONVERSATION_ID,
            senderId = senderId,
            receiverId = EMERGENCY_RECEIVER_ID,
            content = content,
            timestamp = now,
            status = MessageStatus.QUEUED.name,
            priority = MessagePriority.EMERGENCY.name,
            hopCount = 0,
            expiryTime = now + EMERGENCY_TTL_MS,
            isOutgoing = true
        )
        messageDao.insert(message)

        var emergency = EmergencyMessageEntity(
            emergencyId = Ids.newId(),
            messageId = message.messageId,
            content = content,
            createdAt = now,
            status = MessageStatus.QUEUED.name,
            hopCount = 0
        )
        emergencyDao.insert(emergency)

        // Real broadcast: send to every currently connected peer. If there
        // are none, this is a no-op and the alert honestly stays QUEUED —
        // exactly what the Emergency screen's "NO ROUTE" state reports.
        val targets = peerDeviceDao.getConnectedPeerIds()
        val envelope = message.toOutgoingEnvelope()
        val anySent = targets.fold(false) { acc, peerId -> transportManager.send(peerId, envelope) || acc }

        if (anySent) {
            messageDao.updateStatus(message.messageId, MessageStatus.SENT.name)
            emergencyDao.updateStatus(emergency.emergencyId, MessageStatus.SENT.name)
            emergency = emergency.copy(status = MessageStatus.SENT.name)
        }
        return emergency
    }

    // -------- Phase 3: real mesh transport --------

    override fun observeMeshStatus(): StateFlow<MeshStatus> = _meshStatus.asStateFlow()

    override fun observeDiscoveredPeers(): Flow<List<PeerDeviceUi>> =
        peerDeviceDao.observeAll().map { list -> list.filter { it.source == "DISCOVERED" }.map { it.toUi() } }

    override fun startDiscovery() {
        repositoryScope.launch {
            val user = ensureLocalUser("You", "This Device")
            transportManager.setLocalIdentity(user.userId, user.displayName)
            transportManager.startDiscovery()
            transportManager.startAdvertising()
            recomputeMeshStatus()
        }
    }

    override fun stopDiscovery() {
        transportManager.stopDiscovery()
        transportManager.stopAdvertising()
        repositoryScope.launch { recomputeMeshStatus() }
    }

    override fun connectToPeer(peerId: String) {
        transportManager.connect(peerId)
    }

    override fun disconnectFromPeer(peerId: String) {
        transportManager.disconnect(peerId)
    }

    // -------- Transport event handling (the real receive/relay/ack pipeline) --------

    private suspend fun handleTransportEvent(event: MeshTransportEvent) {
        when (event) {
            is MeshTransportEvent.PeerFound -> {
                onPeerFound(event.peerId, event.displayName)
                recomputeMeshStatus()
            }
            is MeshTransportEvent.PeerLost -> {
                onPeerLost(event.peerId)
                recomputeMeshStatus()
            }
            is MeshTransportEvent.Connecting -> {
                updateOrCreatePeerState(event.peerId, PeerConnectionState.CONNECTING)
                recomputeMeshStatus()
            }
            is MeshTransportEvent.Connected -> {
                updateOrCreatePeerState(event.peerId, PeerConnectionState.CONNECTED)
                recomputeMeshStatus()
                flushQueuedMessagesFor(event.peerId)
            }
            is MeshTransportEvent.ConnectionFailed -> {
                Log.w(TAG, "Connection to ${event.peerId} failed: ${event.reason}")
                updateOrCreatePeerState(event.peerId, PeerConnectionState.DISCONNECTED)
                recomputeMeshStatus()
            }
            is MeshTransportEvent.Disconnected -> {
                updateOrCreatePeerState(event.peerId, PeerConnectionState.DISCONNECTED)
                recomputeMeshStatus()
            }
            is MeshTransportEvent.MessageReceived -> {
                if (event.envelope.type == "ack") {
                    // App-level delivery confirmation: the OTHER device
                    // durably stored our message. Only now do we mark our
                    // outgoing copy DELIVERED.
                    messageDao.updateStatus(event.envelope.messageId, MessageStatus.DELIVERED.name)
                } else {
                    handleIncomingMessage(event.fromPeerId, event.envelope)
                }
            }
            is MeshTransportEvent.MessageSendSucceeded -> {
                // Physical-layer confirmation only (bytes reached the
                // peer's radio stack) — this is SENT, not DELIVERED.
                val existing = messageDao.getById(event.messageId)
                if (existing != null && existing.status == MessageStatus.QUEUED.name) {
                    messageDao.updateStatus(event.messageId, MessageStatus.SENT.name)
                }
            }
            is MeshTransportEvent.MessageSendFailed -> {
                Log.w(TAG, "Message send failed: ${event.messageId}")
                messageDao.updateStatus(event.messageId, MessageStatus.FAILED.name)
            }
            is MeshTransportEvent.TransportError -> {
                Log.e(TAG, "Transport error: ${event.message}")
            }
        }
    }

    private suspend fun onPeerFound(peerId: String, displayName: String) {
        val existing = peerDeviceDao.getById(peerId)
        // Don't downgrade an active/in-progress connection just because a
        // stray BLE advertisement pulse was (re)heard.
        val preserveState = existing?.connectionState == PeerConnectionState.CONNECTED.name ||
            existing?.connectionState == PeerConnectionState.CONNECTING.name
        peerDeviceDao.upsert(
            PeerDeviceEntity(
                peerId = peerId,
                displayName = displayName,
                connectionState = if (preserveState) existing!!.connectionState else PeerConnectionState.AVAILABLE.name,
                source = "DISCOVERED",
                lastSeenTimestamp = System.currentTimeMillis(),
                hopsAway = 1
            )
        )
    }

    private suspend fun onPeerLost(peerId: String) {
        val existing = peerDeviceDao.getById(peerId) ?: return
        if (existing.connectionState == PeerConnectionState.CONNECTED.name) return // link may still be live
        peerDeviceDao.upsert(existing.copy(connectionState = PeerConnectionState.DISCONNECTED.name))
    }

    private suspend fun updateOrCreatePeerState(peerId: String, state: PeerConnectionState) {
        val existing = peerDeviceDao.getById(peerId)
        val entity = existing?.copy(connectionState = state.name, lastSeenTimestamp = System.currentTimeMillis())
            ?: PeerDeviceEntity(
                peerId = peerId,
                displayName = peerId.take(8),
                connectionState = state.name,
                source = "DISCOVERED",
                lastSeenTimestamp = System.currentTimeMillis()
            )
        peerDeviceDao.upsert(entity)
    }

    private suspend fun recomputeMeshStatus() {
        val connected = peerDeviceDao.observeConnectedCount().first()
        _meshStatus.value = when {
            connected > 0 -> MeshStatus.CONNECTED
            transportManager.isDiscovering || transportManager.isAdvertising -> MeshStatus.SCANNING
            else -> MeshStatus.OFFLINE
        }
    }

    private suspend fun flushQueuedMessagesFor(peerId: String) {
        val conversation = conversationDao.getByPeerId(peerId) ?: return
        val queued = messageDao.getQueuedForConversation(conversation.conversationId)
        queued.forEach { msg -> transportManager.send(peerId, msg.toOutgoingEnvelope()) }
    }

    private suspend fun handleIncomingMessage(fromPeerId: String, envelope: MeshEnvelope) {
        if (messageDao.exists(envelope.messageId)) {
            // Already have it (direct delivery, or already relayed here via
            // another path) — this IS the loop/duplicate prevention the
            // spec asks for. Still ack politely so the other side doesn't
            // keep retrying, then stop.
            transportManager.send(fromPeerId, MeshEnvelope.ack(envelope.messageId))
            return
        }

        val peer = peerDeviceDao.getById(fromPeerId)
        val displayName = peer?.displayName ?: fromPeerId.take(8)
        val isBroadcast = envelope.receiverId == EMERGENCY_RECEIVER_ID
        val conversation = if (!isBroadcast) getOrCreateConversationForPeer(fromPeerId, displayName) else null
        val storedConversationId = conversation?.conversationId ?: EMERGENCY_BROADCAST_CONVERSATION_ID

        val message = MessageEntity(
            messageId = envelope.messageId,
            conversationId = storedConversationId,
            senderId = envelope.senderId,
            receiverId = envelope.receiverId,
            content = envelope.content,
            timestamp = envelope.timestamp,
            // It has now genuinely arrived and been durably stored on this
            // device — DELIVERED is the honest status for an inbound copy.
            status = MessageStatus.DELIVERED.name,
            priority = envelope.priority,
            hopCount = envelope.hopCount,
            expiryTime = envelope.expiryTime,
            isOutgoing = false
        )
        messageDao.insert(message)
        conversation?.let { conversationDao.updateLastMessage(it.conversationId, envelope.content, envelope.timestamp) }

        // App-level ack lets the ORIGINAL sender (not necessarily fromPeerId,
        // once relay is in play) know their message is durably stored
        // somewhere real. For Phase 3's direct 1:1 case, fromPeerId IS the
        // original sender, so this is exactly right; Phase 5 will need to
        // route this ack back along the relay path instead.
        transportManager.send(fromPeerId, MeshEnvelope.ack(envelope.messageId))

        if (isBroadcast && envelope.priority == MessagePriority.EMERGENCY.name && envelope.hopCount < MAX_RELAY_HOPS) {
            val relayedToAny = relayToOtherPeers(excludePeerId = fromPeerId, envelope = envelope)
            emergencyDao.insert(
                EmergencyMessageEntity(
                    emergencyId = Ids.newId(),
                    messageId = envelope.messageId,
                    content = envelope.content,
                    createdAt = envelope.timestamp,
                    status = if (relayedToAny) MessageStatus.RELAYED.name else MessageStatus.DELIVERED.name,
                    hopCount = envelope.hopCount
                )
            )
        }
    }

    /**
     * Minimal, real multi-hop relay for EMERGENCY broadcasts: forward to
     * every other currently connected peer, with hopCount incremented and
     * capped by MAX_RELAY_HOPS. This is intentionally narrow in scope for
     * Phase 3 (emergency broadcasts only, no per-destination routing table)
     * — full multi-hop relay for ordinary 1:1 messages across an arbitrary
     * mesh topology is Phase 5's job. The wire format (hopCount, expiryTime)
     * and the dedup-by-messageId mechanism above are already exactly what
     * Phase 5 needs; this function is the first real user of both.
     */
    private suspend fun relayToOtherPeers(excludePeerId: String, envelope: MeshEnvelope): Boolean {
        val targets = peerDeviceDao.getConnectedPeerIds().filter { it != excludePeerId }
        if (targets.isEmpty()) return false
        val relayed = envelope.copy(hopCount = envelope.hopCount + 1)
        var anySent = false
        targets.forEach { peerId -> if (transportManager.send(peerId, relayed)) anySent = true }
        return anySent
    }

    private suspend fun sweepExpiredMessages() {
        val now = System.currentTimeMillis()
        val expired = messageDao.getAllQueuedOutgoing().filter { it.expiryTime in 1 until now }
        expired.forEach { messageDao.updateStatus(it.messageId, MessageStatus.FAILED.name) }
        if (expired.isNotEmpty()) {
            Log.i(TAG, "Expired ${expired.size} message(s) past their TTL, marked FAILED")
        }
    }

    private fun MessageEntity.toOutgoingEnvelope() = MeshEnvelope(
        type = "message",
        messageId = messageId,
        senderId = senderId,
        receiverId = receiverId,
        content = content,
        timestamp = timestamp,
        priority = priority,
        hopCount = hopCount,
        expiryTime = expiryTime
    )
}
