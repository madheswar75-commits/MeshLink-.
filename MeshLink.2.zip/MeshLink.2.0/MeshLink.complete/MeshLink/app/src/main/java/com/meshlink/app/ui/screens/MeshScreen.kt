package com.meshlink.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.meshlink.app.data.DemoData
import com.meshlink.app.data.PeerConnectionState
import com.meshlink.app.ui.theme.MeshGreenSignal
import com.meshlink.app.viewmodel.NearbyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeshScreen(viewModel: NearbyViewModel) {
    val realPeers by viewModel.peers.collectAsState()
    val realConnected = realPeers.count { it.state == PeerConnectionState.CONNECTED }
    val realAvailable = realPeers.count { it.state == PeerConnectionState.AVAILABLE }

    val demoConnected = DemoData.demoPeers.count { it.state == PeerConnectionState.CONNECTED }
    val demoAvailable = DemoData.demoPeers.count { it.state == PeerConnectionState.AVAILABLE }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Mesh") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Live Mesh (real)", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                StatColumn("Connected", realConnected.toString())
                StatColumn("Available", realAvailable.toString())
                StatColumn("Total Discovered", realPeers.size.toString())
            }
            if (realPeers.isEmpty()) {
                Text(
                    "No real devices discovered yet \u2014 scan from the Nearby tab.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }

            HorizontalDivider()

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Network Topology", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                StatusChip("DEMO DATA", MaterialTheme.colorScheme.error)
            }
            Text(
                "This diagram is an illustrative example, not a live render of your real " +
                    "topology \u2014 the real hop-by-hop relay graph arrives in Phase 5.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )

            ElevatedCard(Modifier.fillMaxWidth().height(220.dp)) {
                MeshTopologyCanvas(Modifier.fillMaxSize().padding(16.dp))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                StatColumn("Connected", demoConnected.toString())
                StatColumn("Available", demoAvailable.toString())
                StatColumn("Active Peers", DemoData.demoPeers.size.toString())
            }

            Text("Relay Path (last emergency message)", style = MaterialTheme.typography.titleMedium)
            Text(
                "Phase 3 relays EMERGENCY broadcasts to directly connected peers only. A full " +
                    "hop-by-hop relay path across an arbitrary mesh (e.g. You \u2192 B \u2192 C) will be " +
                    "shown here once Phase 5 (multi-hop relay) is implemented.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
private fun StatColumn(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
    }
}

/**
 * Simple illustrative topology: You (center-top) connected to Peer A,
 * which fans out to Peer B and Peer C — matching the ASCII diagram in
 * the spec. Purely decorative; from Phase 5 this should be driven by the
 * real relay graph built from message hop metadata.
 */
@Composable
private fun MeshTopologyCanvas(modifier: Modifier = Modifier) {
    val nodeColor = MeshGreenSignal
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val you = Offset(w / 2f, h * 0.12f)
        val a = Offset(w / 2f, h * 0.5f)
        val b = Offset(w * 0.2f, h * 0.9f)
        val c = Offset(w * 0.8f, h * 0.9f)

        drawLine(nodeColor, you, a, strokeWidth = 4f)
        drawLine(nodeColor, a, b, strokeWidth = 4f)
        drawLine(nodeColor, a, c, strokeWidth = 4f)

        val radius = 22f
        listOf(you, a, b, c).forEach { p ->
            drawCircle(nodeColor, radius = radius, center = p, style = Stroke(width = 4f))
            drawCircle(nodeColor.copy(alpha = 0.15f), radius = radius, center = p)
        }
    }
}
