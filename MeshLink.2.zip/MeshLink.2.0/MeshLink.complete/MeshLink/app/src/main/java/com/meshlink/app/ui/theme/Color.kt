package com.meshlink.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette: deep signal-blue + emergency-red accent, tuned for a
// "resilient network" feel rather than a generic chat-app look.
val MeshBlue80 = Color(0xFFAFC9FF)
val MeshBlue40 = Color(0xFF2A5CDB)
val MeshBlue20 = Color(0xFF10275C)

val MeshGreenSignal = Color(0xFF23C16B)   // Connected / delivered
val MeshAmberSignal = Color(0xFFF2A93B)   // Connecting / queued
val MeshRedEmergency = Color(0xFFE0304B)  // Emergency / failed

val NeutralGray10 = Color(0xFF1A1C1E)
val NeutralGray20 = Color(0xFF2E3033)
val NeutralGray90 = Color(0xFFE4E2E6)
val NeutralGray99 = Color(0xFFFCFCFF)
