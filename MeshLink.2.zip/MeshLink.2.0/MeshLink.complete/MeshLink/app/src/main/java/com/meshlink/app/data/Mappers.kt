package com.meshlink.app.data

import com.meshlink.app.data.local.entity.ConversationEntity
import com.meshlink.app.data.local.entity.MessageEntity
import com.meshlink.app.data.local.entity.PeerDeviceEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())

fun MessageEntity.toUi(): MessageUi = MessageUi(
    id = messageId,
    text = content,
    timestamp = timeFormat.format(Date(timestamp)),
    status = MessageStatus.valueOf(status),
    isOutgoing = isOutgoing,
    priority = MessagePriority.valueOf(priority),
    hopCount = hopCount
)

fun ConversationEntity.toUi(): ConversationUi = ConversationUi(
    id = conversationId,
    peerName = peerDisplayName,
    lastMessage = lastMessagePreview,
    lastTimestamp = if (lastMessageTimestamp == 0L) "" else timeFormat.format(Date(lastMessageTimestamp)),
    unreadCount = unreadCount
)

fun PeerDeviceEntity.toUi(): PeerDeviceUi = PeerDeviceUi(
    id = peerId,
    displayName = displayName,
    state = PeerConnectionState.valueOf(connectionState),
    hopsAway = hopsAway,
    isDemo = false
)
