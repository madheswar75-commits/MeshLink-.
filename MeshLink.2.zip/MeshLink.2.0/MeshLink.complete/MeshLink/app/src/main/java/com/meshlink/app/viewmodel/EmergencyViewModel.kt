package com.meshlink.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.meshlink.app.data.MessageStatus
import com.meshlink.app.data.local.entity.EmergencyMessageEntity
import com.meshlink.app.data.repository.MeshRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EmergencyViewModel(private val repository: MeshRepository) : ViewModel() {

    val history: StateFlow<List<EmergencyMessageEntity>> = repository.observeEmergencyHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val connectedPeerCount: StateFlow<Int> = repository.observeConnectedPeerCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    /**
     * Persists the alert as HIGH PRIORITY (real DB write), then attempts a
     * real broadcast to every currently connected peer. Which callback
     * fires is read directly off the persisted row's resulting status —
     * not a separate guess — so it can never claim "sent" when nothing
     * actually went out over the radio.
     */
    fun sendEmergency(content: String, onSent: () -> Unit, onNoRoute: () -> Unit) {
        if (content.isBlank()) return
        viewModelScope.launch {
            val result = repository.sendEmergencyMessage(content.trim())
            if (result.status == MessageStatus.SENT.name) onSent() else onNoRoute()
        }
    }

    class Factory(private val repository: MeshRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = EmergencyViewModel(repository) as T
    }
}
