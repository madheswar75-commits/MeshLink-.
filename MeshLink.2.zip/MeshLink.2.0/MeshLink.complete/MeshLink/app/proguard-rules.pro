# Add project-specific ProGuard rules here.
# Room/Compose defaults are enough for Phase 1 — revisit before a real release build.
